# Read Me First
The following was discovered as part of building this project:

* The original package name 'sptech.school.exemplo-action' is invalid and this project uses 'sptech.school.exemplo_action' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/4.1.2/gradle-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.1.2/gradle-plugin/packaging-oci-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html)
* [Spring Boot Actuator](https://docs.spring.io/spring-boot/4.1.2/reference/actuator/index.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)

## API de tarefas

A aplicação disponibiliza uma API REST em `/api/tarefas`. Os dados são mantidos
em memória e são perdidos ao reiniciar a aplicação.

| Método | Endpoint | Descrição |
| --- | --- | --- |
| `GET` | `/api/tarefas` | Lista as tarefas |
| `GET` | `/api/tarefas/{id}` | Busca uma tarefa por ID |
| `POST` | `/api/tarefas` | Cria uma tarefa |
| `PUT` | `/api/tarefas/{id}` | Atualiza uma tarefa |
| `DELETE` | `/api/tarefas/{id}` | Exclui uma tarefa |

O corpo de criação e atualização é JSON, por exemplo:

```json
{
  "descricao": "Estudar Spring Boot",
  "concluida": false
}
```

Uma descrição ausente ou em branco retorna `400 Bad Request`; IDs inexistentes
retornam `404 Not Found`. A criação retorna `201 Created` e o endereço da tarefa
no cabeçalho `Location`.

### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

